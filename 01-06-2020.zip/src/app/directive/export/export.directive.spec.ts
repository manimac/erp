import { ExportDirective } from './export.directive';

describe('ExportDirective', () => {
  it('should create an instance', () => {
    const directive = new ExportDirective();
    expect(directive).toBeTruthy();
  });
});
