export const databaseData = [
    {
        "Id": "NWMME",
        "Value": "NWMME"
    }
]