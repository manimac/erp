export const serverData = [
    {
        "Id": null,
        "Value": null
    }
];