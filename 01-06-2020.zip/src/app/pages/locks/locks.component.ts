import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'erp-locks',
  templateUrl: './locks.component.html',
  styleUrls: ['./locks.component.css']
})
export class LocksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
